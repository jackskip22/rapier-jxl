import type {PackageDecode, JpegRestore, JpegRecompress} from './types.mjs';
import type {ImageResult} from './result.mjs';
import type {ImageInput, EncodeOptions, AnimationInput, AnimationOptions} from './types.mjs';
export type * from './types.mjs';
export {supported} from './index.mjs';
/** Compiles the kernels used by still and animation encoding. */
export function prepare(): Promise<void>;
/** An animation ({width, height, frames}), an animated GIF Blob (its frames, loops and timing), or a still: the full still encoder carries both, one file in place. A GIF Blob given `readAs` goes to the still reader, not the animation reader. */
export function encode(input: AnimationInput, options?: AnimationOptions): Promise<ImageResult>;
export function encode(input: ImageInput, options?: EncodeOptions): Promise<ImageResult>;

/** Where the host reads no JPEG (Node, Deno, Bun), the one setup step for a JPEG input: `configureDecoder(decode, restore,
 * recompress)` with rapier-jxl/decode's decode and rapier-jxl/jpeg's recompress (restore may be null). Without it a JPEG
 * refuses JXL_PLATFORM. One call serves every rapier-jxl module in the realm; null clears it. */
export function configureDecoder(decode: PackageDecode | null, restore?: JpegRestore | null, recompress?: JpegRecompress | null): void;
