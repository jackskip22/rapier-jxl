import type {DecodeOptions, DecodedImage} from './types.mjs';
export type {DecodeOptions, DecodedImage};
/** The whole picture decoded on this thread: every decoder part and the Brotli dictionary are in this module, so nothing
 * loads after its import. A file that is cut or malformed refuses (JXL_DECODE, JXL_INPUT); up to 268,435,456 pixels. */
export function decode(input: Uint8Array | Blob, options?: DecodeOptions): Promise<DecodedImage>;
/** Compiles the WebAssembly kernels before the first decode. Decoding requires WebAssembly with SIMD; without it this
 * and decode() reject with JXL_WASM. */
export function prepare(): Promise<void>;
/** Whether this realm decodes: WebAssembly with SIMD compiles here. supported('webgpu') is false: the decoder runs
 * nothing on WebGPU. */
export function supported(feature?: 'webgpu'): Promise<boolean>;
