import type {PackageDecode, JpegRestore, JpegRecompress} from './types.mjs';
import type {ImageResult} from './result.mjs';
import type {ImageInput, EncodeOptions, PreparationInput, FitOptions, VariantsOptions} from './types.mjs';
import type {ResumableFunction} from './resumable.mjs';
export type * from './types.mjs';
// Types only: page capture's options; the function is rapier-jxl/capture-complete's.
export type {CaptureCompleteOptions, CapturePhotoFidelity as CaptureFidelity} from './capture-complete.mjs';
/** rapier-jxl: the full still encoder in one file, run in place: efforts 1-9, exact or lossy, measured fidelity, WebGPU
 * at lossy efforts 7-9, HDR and deeper samples, ICC and codestream features. An exact, unchanged JPEG File or Blob
 * preserves the original JPEG. At efforts 6-9, a JPEG look request compares the pixel result's size with reversible
 * recompression. jpeg: 'pixels' requires pixel encoding. A preserved JPEG reports fidelity: 'exact', kept: 'jpeg-bytes'
 * and measurements: [], with no measured score. An animation is
 * encoded by rapier-jxl/animation; a file's header and metadata are rapier-jxl/metadata's; a worker and queue over any
 * module is rapier-jxl/codec. Page capture is rapier-jxl/capture and rapier-jxl/capture-complete. */
export const encode: ResumableFunction<(input: ImageInput, options?: EncodeOptions) => Promise<ImageResult>>;
/** Fit the same oriented dimensions to maxBytes within explicit fidelity bounds. No fit is an ordinary result. */
export const fit: ResumableFunction<(input: PreparationInput, options: FitOptions) => Promise<ImageResult>>;
/** Acquire/orient once and encode each explicitly sized output independently. No partial results on cancellation. */
export const variants: ResumableFunction<(input: PreparationInput, options: VariantsOptions) => Promise<ImageResult[]>>;
/** The kernels compiled, with no job. */
export function prepare(): Promise<void>;
/** Whether this realm compiles the WebAssembly kernels with SIMD; with 'webgpu', whether this realm offers a usable WebGPU
 * adapter; a job may still run on WebAssembly. */
export function supported(feature?: 'webgpu'): Promise<boolean>;

/** Where the host reads no JPEG (Node, Deno, Bun), the one setup step for a JPEG input: `configureDecoder(decode, restore,
 * recompress)` with rapier-jxl/decode's decode and rapier-jxl/jpeg's recompress (restore may be null). Without it a JPEG
 * refuses JXL_PLATFORM. One call serves every rapier-jxl module in the realm; null clears it. */
export function configureDecoder(decode: PackageDecode | null, restore?: JpegRestore | null, recompress?: JpegRecompress | null): void;
