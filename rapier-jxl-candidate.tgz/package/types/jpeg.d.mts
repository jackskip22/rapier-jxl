import type {ImageResult} from './result.mjs';
import type {JPEGOptions, JobOptions} from './types.mjs';
import type {ResumableFunction} from './resumable.mjs';
export type {JPEGOptions, JobOptions};
/** A JPEG's coefficients coded as JPEG XL with no loss, with what restore needs to write the same JPEG back. The input
 * and options are taken at the call; maxPixels (at most and by default 268,435,456) bounds the JPEG's size, and
 * restore's (JXL_DIMENSIONS); an input the host cannot hold refuses JXL_MEMORY. Combined APP, COM, inter-marker and inline-tail
 * reconstruction payload above 64 MiB refuses JXL_JPEG. Caller bytes use plain Uint8Array;
 * SharedArrayBuffer backing is refused at runtime with JXL_INPUT. */
export const recompress: ResumableFunction<(input: Uint8Array | Blob, options?: JPEGOptions) => Promise<ImageResult>>;
/** The JPEG a recompressed file was made from, restored exactly. A file with no reconstruction data refuses
 * JXL_RECONSTRUCTION. rapier-jxl/metadata header(bytes).reconstruction says, without a decode, whether the bytes hold a
 * reconstruction box; restore alone says whether the JPEG comes back. */
export const restore: ResumableFunction<(input: Uint8Array | Blob, options?: JobOptions) => Promise<ImageResult>>;
/** Compiles the WebAssembly kernels recompress needs; restore needs none. */
export function prepare(): Promise<void>;
/** Whether this realm compiles the WebAssembly kernels with SIMD, which recompress needs. supported('webgpu') is false. */
export function supported(feature?: 'webgpu'): Promise<boolean>;

export type {ImageJob, ImageVerb, Digest, ResultSource, ResultReason, ResultTransform, ResultFidelity, ResultMeasurement, ResultOtherDecoders, ImageResult} from './result.mjs';
