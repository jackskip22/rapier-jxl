// Astro's sharp service with format="jxl" added. Sharp reads, rotates and resizes; rapier-jxl writes the file.
// Every other format is Astro's sharp service unchanged.
import sharpService from 'astro/assets/services/sharp';
import {encode} from 'rapier-jxl';
import {recompress} from 'rapier-jxl/jpeg';
import {asked, bytes, getHTMLAttributes, propertiesToHash, settings, validateOptions} from './options.mjs';

const FIT = {fill: 'fill', contain: 'inside', cover: 'cover', none: 'outside', 'scale-down': 'inside', outside: 'outside', inside: 'inside'};
let sharp;

async function transform(input, options, config, logger) {
  if (options.format !== 'jxl') return sharpService.transform(input, options, config, logger);
  sharp ??= (await import('sharp')).default;
  const {effort, quality, jpeg} = settings(config);
  const {kernel, limitInputPixels} = config.service.config ?? {};
  const image = sharp(input, {failOn: 'none', limitInputPixels});
  const meta = await image.metadata();
  const own = (!options.width || Math.round(options.width) >= meta.width) && (!options.height || Math.round(options.height) >= meta.height);
  // jpeg: 'exact' keeps a JPEG shown at its own size, with no quality asked: the file restores the original exactly.
  if (jpeg === 'exact' && meta.format === 'jpeg' && asked(options.quality) === undefined && own && !options.background && (meta.orientation ?? 1) === 1)
    return {data: bytes(await recompress(input, {effort}), options.src), format: 'jxl'};
  image.rotate();
  const size = {width: options.width && Math.round(options.width), height: options.height && Math.round(options.height), kernel, withoutEnlargement: true};
  if (options.width && options.height) image.resize({...size, fit: options.fit ? FIT[options.fit] ?? 'inside' : undefined, position: options.position});
  else if (options.width || options.height) image.resize(size);
  if (options.background) image.flatten({background: options.background});
  const {data, info} = await image.ensureAlpha().raw().toBuffer({resolveWithObject: true});
  const pixels = {data: new Uint8Array(data.buffer, data.byteOffset, data.length), width: info.width, height: info.height};
  return {data: bytes(await encode(pixels, {effort, fidelity: {quality: asked(options.quality) ?? quality}}), options.src), format: 'jxl'};
}

export default {...sharpService, validateOptions, getHTMLAttributes, propertiesToHash, transform};
