import type {capture} from './capture.mjs';
import type {recompress, restore} from './jpeg.mjs';
import type {Bytes, CaptureOptions, JPEGOptions, JobOptions} from './types.mjs';
import type {ImageResult} from './result.mjs';

type Awaitable<T> = T | PromiseLike<T>;

/** The immutable original held by the store. generation is a nonempty host identifier (at most 256 characters),
 * and sha256 is the original bytes' SHA-256 as 64 lowercase hexadecimal characters, without a prefix.
 * JPEG operations read file bytes; capture reads straight RGBA8 rows described by ResumablePixels. */
export interface ResumableInput {
  readonly generation: string;
  readonly sha256: string;
  readonly byteLength: number;
  readonly width?: number;
  readonly height?: number;
  /** Defaults to sRGB. */
  readonly colorSpace?: 'srgb' | 'display-p3';
}

/** Capture requires positive pixel dimensions; byteLength is width * height * 4. */
export interface ResumablePixels extends ResumableInput {
  readonly width: number;
  readonly height: number;
}

/** An immutable stored part, at most 1 MiB. hash is its SHA-256 as 64 lowercase hexadecimal characters. */
export interface PartRef {
  readonly hash: string;
  readonly length: number;
}

/** Keep every part until the job no longer needs its checkpoint. Writes are idempotent and finish persisting
 * before they resolve. A call awaits its writes before returning the checkpoint the host saves. Reads return
 * the exact requested byte range or part; a readMany result follows its references' order. */
export interface ResumableStore {
  readSource(offset: number, length: number): Awaitable<Uint8Array>;
  write(ref: PartRef, bytes: Bytes): Awaitable<void>;
  read(ref: PartRef): Awaitable<Uint8Array>;
  readMany?(refs: readonly PartRef[]): Awaitable<readonly Uint8Array[]>;
}

declare const checkpointBrand: unique symbol;
/** An opaque JSON record returned by start or advance. Persist it unchanged after the call's writes finish,
 * using revision to guard the host's save, and pass the latest saved record to the next call. The driver
 * rejects stale, changed or foreign records. The brand exists only in the type system. */
export interface Checkpoint {
  readonly revision: number;
  readonly [checkpointBrand]: true;
}

/** The public verbs whose own steps are attached to the function. Other functions are refused at runtime. */
export type ResumableOperation = typeof capture | typeof recompress | typeof restore;

type OptionKeys = keyof CaptureOptions | keyof JPEGOptions;
type SavedOptions<Options, Keys extends keyof Options> = Readonly<Pick<Options, Keys>> & {
  readonly [K in Exclude<OptionKeys, Keys>]?: never;
};
/** Capture's data-only saved options. Per-call cancellation is supplied to advance or finish. */
export type ResumableCaptureOptions = SavedOptions<CaptureOptions, 'fidelity' | 'effort' | 'webgpu'>;
/** Recompression preserves the JPEG's coefficients and takes these ordinary JPEG settings. */
export type ResumableJPEGOptions = SavedOptions<JPEGOptions, 'effort' | 'icc' | 'maxPixels'>;
/** Restoration admits only the pixel bound in its saved plan. */
export type ResumableRestoreOptions = SavedOptions<JobOptions, 'maxPixels'>;

type OptionsOf<Operation extends ResumableOperation> = NonNullable<Parameters<Operation>[1]>;
export type ResumableOptions<Operation extends ResumableOperation> = Operation extends unknown
  ? 'fidelity' extends keyof OptionsOf<Operation> ? ResumableCaptureOptions
  : 'icc' extends keyof OptionsOf<Operation> ? ResumableJPEGOptions
  : ResumableRestoreOptions
  : never;
type InputOf<Operation extends ResumableOperation> = Operation extends unknown
  ? 'fidelity' extends keyof OptionsOf<Operation> ? ResumablePixels : ResumableInput
  : never;

interface OperationContext<Operation extends ResumableOperation = ResumableOperation> {
  /** Pass the imported verb itself: capture, recompress or restore. */
  readonly operation: Operation;
  readonly store: ResumableStore;
}
/** The operation alone determines the admitted source and option shapes. */
export interface StartOptions<Operation extends ResumableOperation = ResumableOperation> extends OperationContext<Operation> {
  readonly input: InputOf<NoInfer<Operation>>;
  readonly options?: ResumableOptions<NoInfer<Operation>>;
}
export interface FinishOptions extends OperationContext {
  readonly signal?: AbortSignal;
}
export interface AdvanceOptions extends FinishOptions {
  /** Positive milliseconds, at most 60000; defaults to {ms: 30}. A call advances at least one step. */
  readonly budget?: {readonly ms: number};
}
export interface AdvanceResult {
  readonly checkpoint: Checkpoint;
  readonly done: boolean;
}

/** Start the operation over the stored original and return its first durable checkpoint. */
export function start<Operation extends ResumableOperation>(options: StartOptions<Operation>): Promise<Checkpoint>;
/** Advance the latest checkpoint within this call's budget, awaiting every new part's write. */
export function advance(checkpoint: Checkpoint, options: AdvanceOptions): Promise<AdvanceResult>;
/** Assemble a finished checkpoint's output and return the ordinary operation's common result record. */
export function finish(checkpoint: Checkpoint, options: FinishOptions): Promise<ImageResult>;
