import type {ImageResult} from './result.mjs';
// Narrow preparation types shared by the upload entry, its codec and private entry composition.
import type {UploadInput, UploadOptions, FitOptions, FitFidelity, StillFidelity, PreparationInput, TextureInput, Bytes, EmptyFeatures, OutputSize} from './types.mjs';
/** What upload's fit and variants read: one still image, at most 40,000,000 pixels, not a texture. */
export type UploadPreparationInput = Exclude<PreparationInput, TextureInput>;
/** fit's options with upload's efforts 1-3 and no features. */
export type UploadFitOptions = Omit<FitOptions, 'effort' | 'features'> & {
  /** 1 (fastest) to 3 (smallest file); default 3. */
  effort?: 1 | 2 | 3;
  /** Takes no codestream features; pass none. */
  features?: EmptyFeatures};
/** One output of upload's variants: its size, and its own effort (1-3), JPEG policy, maxBytes or fidelity. */
export type UploadVariantRequest = OutputSize & {effort?: 1 | 2 | 3; features?: EmptyFeatures; /** As encode's JPEG policy. */ jpeg?: 'pixels'} & (
  {maxBytes: number; fidelity?: FitFidelity} |
  {maxBytes?: never; fidelity?: StillFidelity}
);
/** upload's options plus the outputs wanted. */
export type UploadVariantsOptions = UploadOptions & {
  /** One entry per file wanted. */
  outputs: readonly UploadVariantRequest[]};
/** A fit and a variants call over one picture, for a queue that prepares uploads. */
export interface UploadPreparation {
  fit(input: UploadPreparationInput, options: UploadFitOptions): Promise<ImageResult>;
  variants(input: UploadPreparationInput, options: UploadVariantsOptions): Promise<ImageResult[]>;
}
/** Internal entry composition: the supplied encoder writes every file; hooks are entry-owned implementation wiring. */
export function preparationUpload(encode: (input: UploadInput, options?: UploadOptions) => Promise<Bytes>, hooks?: object): UploadPreparation;
