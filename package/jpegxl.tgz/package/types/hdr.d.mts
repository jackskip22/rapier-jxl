// SPDX-License-Identifier: MIT
import type {ColorEncoding} from './codec/icc.mjs';

/** The picture record `encode` takes, read from a file: RGBA, straight rows, linear light, exact samples.
 * `sampleFormat` is 'float16' (raw binary16 words in a Uint16Array) when every sample is exactly a half, else 'float32'.
 * A picture without alpha has alpha 1. Nothing is tone-mapped, converted or scaled. */
export interface HdrPicture {
  data: Uint16Array | Float32Array;
  width: number;
  height: number;
  bitDepth: 16 | 32;
  sampleFormat: 'float16' | 'float32';
  /** Present when the file's primaries and white point are sRGB, Display P3 or Rec. 2020 (D65): `encode(picture)` takes it. */
  colorSpace?: 'srgb' | 'display-p3' | 'rec2020' | undefined;
  /** Present instead when they are any others, exactly as the file states them: `encode(picture)` and `format({kind: 'profile', ...picture})` take it. */
  colorEncoding?: Pick<ColorEncoding, 'space' | 'whitePoint' | 'primaries'> | undefined;
  transferFunction: 'linear';
  /** OpenEXR color is associated with alpha (premultiplied), unless every alpha is 1, which reads as straight; Radiance has no alpha. */
  alphaPremultiplied: boolean;
  /** OpenEXR whiteLuminance, in nits. */
  intensityTarget?: number | undefined;
}
export interface HdrOptions {
  /** OpenEXR only. 'data' (default) is the pixels the file stores; 'display' is its display window, transparent black
   * where the data window does not reach. */
  window?: 'data' | 'display' | undefined;
}
/** Read an OpenEXR (.exr) or Radiance (.hdr) file. Errors carry the encoder's codes: JXL_INPUT (malformed, or a feature
 * named in the message that is not read), JXL_DIMENSIONS (over 40,000,000 pixels or 65,535 on a side), JXL_MEMORY.
 *
 * OpenEXR: single-part scan-line and tiled files (level 0 of mip and rip maps); HALF or FLOAT R, G, B or Y with optional A
 * (every other channel is skipped); NONE, RLE, ZIPS and ZIP. Refused by name: PIZ, PXR24, B44, B44A, DWAA and DWAB
 * (not supported yet), multi-part and deep files, subsampled (luminance-chroma) channels, UINT color channels, pixel aspect other than 1.
 * Radiance: -Y +X, new run-length or flat rows, RGBE; EXPOSURE and COLORCORR are not applied. Refused: XYZE, old
 * run-length rows, other orientations.
 * ZIP data is inflated by the platform's DecompressionStream, so the realm needs it (browsers, workers, Node 18+, Deno, Bun,
 * Cloudflare Workers). At most 2 GiB of picture data is unpacked and 640 MB allocated for a 40,000,000 pixel float32 picture. */
export function read(input: Uint8Array | ArrayBuffer | Blob, options?: HdrOptions): Promise<HdrPicture>;
