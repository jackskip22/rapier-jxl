import type {Bytes, WorkerLike, DecodeOptions, DecodedImage} from './types.mjs';
/** Options for polyfill(); all are optional. */
export interface PolyfillOptions {
  /** The document to patch; default the global one. */
  document?: Document;
  /** Where to look for images: a document, element or shadow root; default the document. */
  root?: Document | Element | ShadowRoot;
  /** A JPEG XL data or image URL the native test loads; default a built-in one. */
  probeURL?: string;
  /** true decodes every image here, even where the browser shows JPEG XL itself; default false. */
  force?: boolean;
  /** Images decoded at once, 1 to 4; default 2. */
  workers?: 1 | 2 | 3 | 4;
  /** Bytes for decoded images (default 128 MiB): each decode, one per worker at once, is bounded by it alone, and the
   * images shown together stay under it. Not one cap on all the polyfill's memory. A decode holds about 32 bytes a
   * pixel: 128 MiB shows up to 4.2 MP, and a 12 MP photograph needs about 1 GiB. A larger picture fails with
   * JXL_DIMENSIONS, naming its size and this limit. */
  maxDecodedBytes?: number;
  /** Largest file fetched, in bytes; default 32 MiB. A larger one fails with JXL_LIMIT. */
  maxInputBytes?: number;
  /** How far off screen an image starts decoding, in pixels or percent; default '1000px'. */
  rootMargin?: string;
  /** Makes the decode worker; for a bundler or a Content Security Policy that needs your own URL. */
  workerFactory?: () => WorkerLike;
  /** Your own decoder in place of the package's (a native or a server-side one): it receives owned bytes and may
   * return the decoded image directly or asynchronously. */
  decode?: (bytes: Bytes, options: DecodeOptions) => DecodedImage | PromiseLike<DecodedImage>;
  /** An image that could not be shown. `error.code` is the decoder's ErrorCode, or one of the polyfill's own:
   * JXL_FETCH (the image request failed), JXL_IMAGE_CSP (the page's image policy refuses decoded images) or
   * JXL_DISPLAY (the decoded picture could not be put on screen). */
  onError?: (error: unknown, element: Element) => void;
}
export interface PolyfillController {
  readonly status: 'active' | 'native' | 'probe-blocked' | 'unavailable' | 'closed';
  readonly stats?: {elements: number; resources: number; active: number; queued: number};
  refresh(): void;
  disconnect(): void;
}
/** null means policy or a timeout prevented detection, not lack of native support. */
export function supportsJXL(document?: Document, probeURL?: string): Promise<boolean | null>;
/** Explicit installation supersedes automatic installation. Repeated explicit calls reuse it until disconnected.
 * Options are read once, at the call; invalid ones reject with JXL_OPTIONS and leave any earlier installation connected. */
export function install(options?: PolyfillOptions): Promise<PolyfillController>;
/** Initial installation. If already settled, its controller can later be closed by explicit installation. */
export const ready: Promise<PolyfillController | null>;
