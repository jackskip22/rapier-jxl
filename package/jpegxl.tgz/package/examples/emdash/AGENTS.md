# EmDash image optimization — migration-agent guidance

This integration is EmDash's own image optimization. It replaces the image-optimization
plug-ins a site may have used before moving to EmDash.

Use `npx jpegxl add emdash` in the target EmDash site's folder. Preserve its native
media repository, database, local/R2 storage, and application configuration. The
plug-in implements no other plug-in's API, settings import or database schema, and must
not be described as a drop-in for one.

For media already copied into EmDash local/R2 storage **with ready media records**
(an imported site's included), the Media page's **Convert N older images** discovers
them from the native paginated media catalog; the upload hook is not required.
Confirm source binding and preserved source bytes before conversion.

JPEG originals may be archived reversibly only under a verified host policy. Worker
operations go through the single measured `workerAdmission` reader; rows or sizes
not certified are browser work. Never infer Paid/Free from errors or bypass the
**Keep original JPEG files** physical custody switch. The public registry listing is
owner-controlled and is not the migration-agent description.
