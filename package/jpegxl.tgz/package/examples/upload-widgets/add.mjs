// npx jpegxl add uppy | filepond [--dir <folder>] [--dry-run] [--json]: copies the plug-in and shrink.mjs into the
// app, installs rapier-jxl with the app's package manager when it is missing, and prints the two lines that wire it.
// Run again, it changes nothing; a copied file the person edited is never replaced.
import {readFile, writeFile, mkdir, stat} from 'node:fs/promises';
import {join, relative, resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';

const HOSTS = {
  uppy: {name: 'Uppy', dependency: '@uppy/core', file: 'uppy.mjs', wire: path => [`import Jxl from '${path}';`, 'uppy.use(Jxl);']},
  filepond: {name: 'FilePond', dependency: 'filepond', file: 'filepond.mjs', wire: path => [`import jxl from '${path}';`, 'FilePond.registerPlugin(jxl);']},
};
const setup = (message, fix) => Object.assign(new Error(`${message} Fix: ${fix}`), {code: 'JXL_SETUP', fix});
const hash = text => createHash('sha256').update(text).digest('hex').slice(0, 16);
// The first line names the version and the hash of the rest, so a later add can tell an unedited copy from an edit.
const stamp = (version, body) => `// rapier-jxl ${version}, copied by npx jpegxl add: ${hash(body)}\n${body}`;
const STAMP = /^\/\/ rapier-jxl \S+, copied by npx jpegxl add: ([0-9a-f]{16})\n/;

export async function runAdd(host, args, {cwd, version, stdout, env = process.env}) {
  if (!HOSTS[host]) throw setup(`No integration named ${host}.`, 'run npx jpegxl add uppy or npx jpegxl add filepond.');
  let dir, dryRun = false, json = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--dir' && dir === undefined && args[i + 1] && !args[i + 1].startsWith('-')) dir = args[++i];
    else if (args[i] === '--dry-run') dryRun = true;
    else if (args[i] === '--json') json = true;
    else throw Object.assign(setup(`Unknown option ${args[i]}.`, `run npx jpegxl add ${host} [--dir <folder>] [--dry-run] [--json].`), {code: 'JXL_OPTIONS'});
  }
  const {name: widget, dependency, file, wire} = HOSTS[host];
  let pkg;
  try { pkg = JSON.parse(await readFile(join(cwd, 'package.json'), 'utf8')); }
  catch { throw setup('No package.json here.', `run npx jpegxl add ${host} in the app's folder, beside its package.json.`); }
  const has = name => pkg.dependencies?.[name] ?? pkg.devDependencies?.[name];
  if (!has(dependency)) throw setup(`This app does not depend on ${dependency}.`, `install ${host} first (npm install ${dependency}), or run this in the app that uses it.`);
  dir ??= await isDir(join(cwd, 'src')) ? 'src/rapier-jxl' : 'rapier-jxl';
  const target = resolve(cwd, dir), shown = relative(cwd, target).split('\\').join('/');
  if (shown.startsWith('..')) throw Object.assign(setup('--dir is outside the app.', 'name a folder inside it, such as src/rapier-jxl.'), {code: 'JXL_OPTIONS'});
  const changed = [], unchanged = [];
  const writes = [];
  for (const name of ['shrink.mjs', file]) {
    const body = await readFile(new URL(name, import.meta.url), 'utf8'), wanted = stamp(version, body);
    const path = join(target, name), present = await readFile(path, 'utf8').catch(() => null);
    if (present === wanted) { unchanged.push(`${shown}/${name}`); continue; }
    if (present !== null) {
      const own = present.match(STAMP);
      if (!own || hash(present.slice(own[0].length)) !== own[1])
        throw setup(`${shown}/${name} has edits of yours, so it was left as it is.`, `move your edits elsewhere and delete the file, or pass --dir <another folder>, then run npx jpegxl add ${host} again.`);
    }
    writes.push([path, wanted]); changed.push(`${shown}/${name}`);
  }
  const install = has('rapier-jxl') ? null : `rapier-jxl@${version}`;
  if (!dryRun) {
    await mkdir(target, {recursive: true});
    for (const [path, text] of writes) await writeFile(path, text);
    if (install) await installPackage(cwd, install, env);
  }
  // The import as written in a file beside the folder (src/main.js for src/rapier-jxl): the usual place an app creates its widget.
  const next = wire(`./${shown.split('/').at(-1)}/${file}`);
  if (json) stdout(JSON.stringify({type: 'add', host, dryRun, changed, unchanged, installed: install, plugin: `${shown}/${file}`, next}));
  else {
    const verb = dryRun ? 'would write' : 'wrote';
    for (const path of changed) stdout(`${verb} ${path}`);
    for (const path of unchanged) stdout(`unchanged ${path}`);
    if (install) stdout(`${dryRun ? 'would install' : 'installed'} ${install}`);
    stdout(`Then, in the file that creates ${widget} (the import path is from that file to ${shown}/${file}):\n  ${next.join('\n  ')}`);
  }
}

const isDir = path => stat(path).then(s => s.isDirectory(), () => false);

async function installPackage(cwd, spec, env) {
  const locks = [['pnpm-lock.yaml', 'pnpm'], ['yarn.lock', 'yarn'], ['bun.lock', 'bun'], ['bun.lockb', 'bun']];
  let manager = 'npm';
  for (const [lock, name] of locks) if (await stat(join(cwd, lock)).then(() => true, () => false)) { manager = name; break; }
  const args = manager === 'npm' ? ['install', '--save-exact', '--no-audit', '--no-fund', spec]
    : manager === 'pnpm' ? ['add', '--save-exact', spec] : ['add', '--exact', spec];
  // npx names npm's JavaScript entry; running it with Node also works on Windows without a shell.
  const npm = manager === 'npm' && /(?:^|[/\\])npm(?:-cli)?\.(?:c?js|mjs)$/.test(env.npm_execpath ?? '');
  const code = await new Promise((done, failed) => spawn(npm ? process.execPath : manager, npm ? [env.npm_execpath, ...args] : args,
    {cwd, env, stdio: 'inherit', shell: false}).on('error', failed).on('exit', done)).catch(() => -1);
  if (code !== 0) throw setup(`${manager} could not install ${spec}.`, `run ${manager} ${args.join(' ')} yourself, then npx jpegxl add again.`);
}
