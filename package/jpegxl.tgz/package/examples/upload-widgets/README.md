# JPEG XL for Uppy and FilePond

Photographs become JPEG XL on the person's device before they are uploaded. A 12 MP phone photo goes up at about a
sixth of its size: 34.9 MB of seven phone JPEGs became 6.1 MB, a quarter less than Uppy's Compressor sends at its
default, and at the same look or better on every photo.

rapier-jxl is the encoder inside rapier.website, the free Markdown editor and painting app.

## Install

In the app's folder:

```sh
npx jpegxl add uppy       # or: npx jpegxl add filepond
```

It copies `shrink.mjs` and the plug-in into `src/rapier-jxl/`, installs `rapier-jxl` when it is missing, and prints
the two lines for the file that creates the widget. `--dir <folder>`, `--dry-run` and `--json` are taken. Run again,
it changes nothing, and it never replaces a copied file you edited.

### Uppy

```js
import Uppy from '@uppy/core';
import Jxl from './rapier-jxl/uppy.mjs';

const uppy = new Uppy().use(Jxl); // in place of @uppy/compressor
```

| Option | Default | Meaning |
| --- | --- | --- |
| `fidelity` | `{quality: 70}` | `{quality: 1–100}`, or `'exact'`. `100` and `'exact'` keep a JPEG byte-exact: about a sixth smaller, and the original restores. |
| `effort` | `3` | `1`–`3`. At quality 70 they write nearly the same file; 1 is about 15% faster. |
| `retainExif` | `false` | `true` copies a JPEG's Exif, with its orientation set to 1. |
| `helpers` | `true` | Parallel workers sized by the device; `false` for one worker. The same file either way. |
| `maxPixels` | 40,000,000 | Larger photos go up as they were; up to 268,435,456. |

### FilePond

```js
import * as FilePond from 'filepond';
import jxl from './rapier-jxl/filepond.mjs';

FilePond.registerPlugin(jxl);
FilePond.create(input, {imageJxlQuality: 70});
```

Options: `allowImageJxl` (`true`), `imageJxlQuality` (`70`; `100` keeps a JPEG byte-exact), `imageJxlEffort` (`3`),
`imageJxlRetainExif` (`false`). With a server, files are made smaller when their upload starts; for a form post,
when they are added.

### Any other widget

```js
import {shrinker} from './rapier-jxl/shrink.mjs';

const {shrink} = shrinker();
const {file, code} = await shrink(picked); // file: the JPEG XL file, or the original when code says why
```

## What goes up

- A JPEG, PNG, WebP or HEIC still that rapier-jxl makes smaller goes up as `image/jxl`, named `.jxl`.
- Everything else goes up as it was picked: other types, GIFs and animated PNG or WebP, a file JPEG XL would not make
  smaller, and any file rapier-jxl refuses. The upload never fails because of rapier-jxl. Uppy logs
  `[Jxl] <id> uploads as picked: <code>`:

| Code | When |
| --- | --- |
| `JXL_INPUT` | The browser cannot decode the file: HEIC in Chrome. |
| `JXL_DIMENSIONS` | Over `maxPixels`. |
| `JXL_JPEG` | A damaged JPEG. |
| `animated`, `type`, `larger` | Kept by the plug-in itself. |

A Content Security Policy must allow `'wasm-unsafe-eval'`.

The photo is turned upright by its Exif orientation, as the browser shows it. Exif is dropped unless kept by the
option; color profiles such as Display P3 are converted to sRGB.

## Measured

Seven 12 MP phone photos (Pixel 7, 8 Pro, 10 Pro XL, Galaxy S23, S25 Ultra, OnePlus 12, iPhone 15 Pro Max; openly
licensed, from the repository's open phone corpus), in Chromium 141 with the Pixel 7 profile on a 4-core Xeon at 2.1 GHz.
The look is libjxl 0.12.0's `ssimulacra2` on `djxl`'s decode against the upright original.

| | Uppy Compressor 0.6 | rapier-jxl, quality 70 |
| --- | --- | --- |
| Bytes, all seven | 8,203,332 | 6,075,327 (25.9% fewer; originals 34,876,887) |
| Look | | at or over Compressor's on all seven |
| Time per photo, median | 383 ms, on the page's thread | 838 ms, in a worker (1,072 ms without helpers) |
| Memory, one photo | 142–201 MB | 221–253 MB (120–165 MB without helpers) |

At the same look as Compressor's default, JPEG XL is 28.5% to 43.4% smaller (median 37.5%). FilePond's image transform
writes the same JPEG bytes as Compressor at the same quality, in 1,738 ms. At a phone's speed (Chrome DevTools'
4x mid-tier factor) the photo takes about 3.4 s in the worker, while Compressor holds the page for about 1.5 s
(2,658 ms measured with the factor on the page's thread).
