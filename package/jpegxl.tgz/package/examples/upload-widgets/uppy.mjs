// JPEG XL for Uppy: uppy.use(Jxl) makes each photograph smaller on the device before it is uploaded. A file that
// would not get smaller, or that rapier-jxl refuses (any JXL_* code), goes up as it was picked.
import {BasePlugin} from '@uppy/core';
import {shrinker} from './shrink.mjs';

const defaultOptions = {fidelity: {quality: 70}, effort: 3, retainExif: false, helpers: true};

export default class Jxl extends BasePlugin {
  constructor(uppy, opts) {
    super(uppy, {...defaultOptions, ...opts});
    this.id = this.opts.id || 'Jxl';
    this.type = 'modifier';
    this.defaultLocale = {strings: {compressingImages: 'Making photos smaller…'}};
    this.i18nInit();
    this.prepareUpload = this.prepareUpload.bind(this);
  }

  async prepareUpload(fileIDs) {
    const {shrink} = this.shrinker ??= shrinker(this.opts);
    await Promise.all(fileIDs.map(async id => {
      const file = this.uppy.getFile(id);
      if (!file || file.isRemote || !(file.data instanceof Blob)) return;
      const progress = value => this.uppy.emit('preprocess-progress', file,
        {mode: 'determinate', message: this.i18n('compressingImages'), value});
      progress(0);
      const picked = file.data instanceof File ? file.data : new File([file.data], file.name, {type: file.type});
      const {file: out, code} = await shrink(picked, {onProgress: progress});
      if (code) this.uppy.log(`[Jxl] ${file.id} uploads as picked: ${code}`);
      else {
        const name = out.name, meta = file.meta.name.replace(/\.[^.]*$/, '') + '.jxl';
        this.uppy.setFileState(id, {name, extension: 'jxl', type: out.type, size: out.size, data: out,
          meta: {...file.meta, name: meta, type: out.type}});
      }
      this.uppy.emit('preprocess-complete', this.uppy.getFile(id));
    }));
  }

  install() { this.uppy.addPreProcessor(this.prepareUpload); }

  uninstall() {
    this.uppy.removePreProcessor(this.prepareUpload);
    this.shrinker?.close();
    this.shrinker = undefined;
  }
}
