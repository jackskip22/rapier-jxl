# Upload widgets: guidance for agents

Photographs become JPEG XL on the person's device before Uppy or FilePond uploads them.

## Wire it

1. In the app's folder (beside its `package.json`): `npx jpegxl add uppy` or `npx jpegxl add filepond`.
   It copies `shrink.mjs` and the plug-in into `src/rapier-jxl/` (or `rapier-jxl/` when there is no `src/`; `--dir`
   names another folder inside the app), installs `rapier-jxl` when it is missing, and prints two lines.
   `--dry-run` shows what it would do; `--json` prints one object.
2. Add the two lines where the app creates the widget:
   - Uppy: `import Jxl from './rapier-jxl/uppy.mjs'` and `uppy.use(Jxl)`. Remove `@uppy/compressor` from that Uppy:
     both would compress the same file.
   - FilePond: `import jxl from './rapier-jxl/filepond.mjs'` and `FilePond.registerPlugin(jxl)`. Leave
     `filepond-plugin-image-transform` out unless the app crops or resizes; with it, rapier-jxl encodes its output.
3. The page's Content Security Policy must allow `'wasm-unsafe-eval'` and workers from the app's own origin.

## Check it worked

- Pick a JPEG photo: the uploaded file is `image/jxl`, named `.jxl`, and smaller than the photo.
- Uppy logs `[Jxl] <id> uploads as picked: <code>` for each file that went up unchanged; the code says why.
- The server must accept `image/jxl`. Edge does not display JPEG XL: serve those visitors another file
  (`rapier-jxl/serve` serves an exact JPEG back when `quality: 100` kept the JPEG), or keep the original as well.

## Do not

- Do not edit the copied files: `add` refuses to replace a file that was edited, so a later version cannot update it.
  Pass options instead (`uppy.use(Jxl, {fidelity: {quality: 80}, effort: 3, retainExif: true})`; FilePond
  `imageJxlQuality`, `imageJxlEffort`, `imageJxlRetainExif`, `allowImageJxl`).
- Do not catch or retry rapier-jxl's errors around the plug-in: a refused file (any `JXL_*` code) already goes up as
  it was picked, and the upload never fails because of rapier-jxl.
- Do not raise `effort` above 3: `rapier-jxl/upload` takes efforts 1 to 3.
