// An upload queue in a page: several photos go through one worker, one at a time and in order, each
// with its own progress, cancel and errors that carry a code. Pick files with the input, or call window.run() for a
// self-contained demonstration.
// With a bundler (Vite, webpack, Rollup, esbuild): import {createCodec} from 'jpegxl/codec/upload';
import {createCodec} from '../dist/codec.mjs';

// One owned queue over the upload module: its own worker, input copied at submission, bounded memory and job count.
const queue = createCodec({module: 'rapier-jxl/upload', maxPixels: 16_000_000, maxPendingBytes: 64 * 1024 * 1024, maxPendingJobs: 8});
// Cancel all aborts the uploads already chosen; files chosen after it get a fresh controller.
let cancelAll = new AbortController();
const list = document.querySelector('#list');

function row(name) {
  const item = document.createElement('li'), progress = document.createElement('progress');
  item.textContent = name + ' ';
  item.append(progress);
  list.append(item);
  return {progress, done(text) { progress.remove(); item.append(text); }};
}

// One upload: encode, then hand the JPEG XL file to whatever stores it (here, a Blob for the page).
// A cancel rejects with the signal's AbortError; every other refusal carries a JXL_ code.
const codeOf = error => error?.name === 'AbortError' ? 'AbortError' : error?.code ?? error?.name;
function upload(file, {signal = cancelAll.signal, effort = 3, quality = 82} = {}) {
  const view = row(file.name), progress = [];
  const onProgress = fraction => { progress.push(fraction); view.progress.value = fraction; };
  // A page's Content Security Policy must allow 'wasm-unsafe-eval'.
  return queue.encode(file, {effort, fidelity: {quality}, signal, onProgress}).then(result => {
    if (!result.fits) throw Object.assign(new Error(result.reason.message), {code: result.reason.code});
    view.done(`${result.bytes.length} bytes`);
    return {name: file.name, ok: true, bytes: result.bytes.length, progress,
      original: file, result, jxl: new Blob([result.bytes], {type: 'image/jxl'})};
  }).catch(error => {
    view.done(`${codeOf(error)}: ${error.message}`);
    return {name: file.name, ok: false, code: codeOf(error), progress, original: file};
  });
}

document.querySelector('#files').addEventListener('change', event => { for (const file of event.target.files) upload(file); });
document.querySelector('#cancel').addEventListener('click', () => { cancelAll.abort(); cancelAll = new AbortController(); });

// A phone-like photo as a JPEG File, drawn in the page.
async function photo(name, width, height, seed) {
  const canvas = new OffscreenCanvas(width, height), g = canvas.getContext('2d');
  const sky = g.createLinearGradient(0, 0, 0, height);
  sky.addColorStop(0, `hsl(${200 + seed * 7} 60% 70%)`); sky.addColorStop(1, `hsl(${30 + seed * 11} 50% 45%)`);
  g.fillStyle = sky; g.fillRect(0, 0, width, height);
  for (let i = 0; i < 120; i++) {
    g.fillStyle = `hsl(${(seed * 41 + i * 17) % 360} 55% ${35 + (i % 30)}%)`;
    g.beginPath(); g.arc((i * 97 + seed * 31) % width, height / 2 + ((i * 53) % (height / 2)), 6 + (i % 25), 0, 7); g.fill();
  }
  return new File([await canvas.convertToBlob({type: 'image/jpeg', quality: 0.92})], name, {type: 'image/jpeg'});
}

// The demonstration: four photos in order, one canceled while it waits, one larger than the queue's pixel limit, a
// truncated file, and a request refused because the queue is full. Every result comes back; none is lost.
window.run = async () => {
  const started = performance.now(), order = [];
  const photos = await Promise.all([1, 2, 3, 4].map(n => photo(`photo-${n}.jpg`, 1600, 1200, n)));
  const cancelOne = new AbortController();
  const jobs = photos.map((file, i) => upload(file, i === 2 ? {signal: cancelOne.signal} : {}).then(result => (result.ok && order.push(file.name), result)));
  cancelOne.abort();
  const huge = await photo('panorama.jpg', 6000, 3000, 9);
  jobs.push(upload(huge));
  const broken = new File([new Uint8Array([255, 216, 255, 224, 0, 16])], 'truncated.jpg', {type: 'image/jpeg'});
  jobs.push(upload(broken));
  const results = await Promise.all(jobs);
  // A full queue refuses at once: fill the eight places, then ask for one more.
  const blocker = Array.from({length: 8}, () => queue.encode({data: new Uint8Array(4), width: 1, height: 1}, {fidelity: 'exact', effort: 1}).catch(error => error));
  const full = await queue.encode({data: new Uint8Array(4), width: 1, height: 1}).then(() => null, error => error.code);
  await Promise.all(blocker);
  return {results: results.map(({name, ok, bytes, code, progress}) => ({name, ok, bytes, code, progress})), order, queueFull: full,
    stats: queue.stats, ms: Math.round(performance.now() - started)};
};
