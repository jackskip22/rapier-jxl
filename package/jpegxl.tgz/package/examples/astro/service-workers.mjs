// The same service inside a Cloudflare Worker, for on-demand images (no sharp there). format="jxl":
//   a JPEG at its own size with jpeg: 'exact' and no quality is recompressed (restores the original exactly);
//   otherwise the pixels come from the Images binding (env.IMAGES, resized as asked) or, for a PNG, from rapier-jxl itself.
// Other formats go through the Images binding when the Worker has one. Whatever cannot be made, or any JXL_* refusal,
// serves the original file: a page never breaks for the encoder.
import {baseService} from 'astro/assets';
import {encode, variants} from 'jpegxl';
import {recompress} from 'jpegxl/jpeg';
import {asked, bytes, getHTMLAttributes, propertiesToHash, settings, validateOptions} from './options.mjs';

const MIME = {jxl: 'image/jxl', webp: 'image/webp', avif: 'image/avif', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg'};
const FIT = {fill: 'pad', contain: 'contain', cover: 'cover', none: 'scale-down', 'scale-down': 'scale-down', outside: 'cover', inside: 'contain'};
// A JPEG's size from its first frame header.
function jpegSize(data) {
  for (let at = 2; at + 9 < data.length; at += 2 + (data[at + 2] << 8 | data[at + 3])) {
    if (data[at] !== 0xff) return null;
    const marker = data[at + 1];
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc)
      return {height: data[at + 5] << 8 | data[at + 6], width: data[at + 7] << 8 | data[at + 8]};
  }
  return null;
}
const kind = data => data[0] === 0xff && data[1] === 0xd8 ? 'jpeg' : data[0] === 0x89 && data[1] === 0x50 ? 'png' : null;

let images;
async function binding(config) {
  if (images === undefined) {
    const name = config.service.config?.imagesBindingName ?? 'IMAGES';
    try { images = (await import('cloudflare:workers')).env[name] ?? null; } catch { images = null; }
  }
  return images;
}

async function through(images, input, options, mime, quality) {
  const size = {width: options.width && Math.round(options.width), height: options.height && Math.round(options.height)};
  const fit = options.width && options.height ? FIT[options.fit] ?? 'contain' : 'scale-down';
  const result = await images.input(new Blob([input]).stream()).transform({...size, fit, ...(options.background && {background: options.background})}).output({format: mime, ...(quality && {quality})});
  return new Uint8Array(await result.response().arrayBuffer());
}

async function transform(input, options, config, logger) {
  const source = kind(input), original = {data: input, format: source === 'jpeg' ? 'jpg' : source ?? 'png'};
  const images = await binding(config);
  try {
    if (options.format !== 'jxl') return images && MIME[options.format] ? {data: await through(images, input, options, MIME[options.format], asked(options.quality)), format: options.format} : original;
    const {effort, quality, jpeg, maxPixels} = settings(config, true);
      if (jpeg === 'exact' && source === 'jpeg' && asked(options.quality) === undefined && !options.background) {
      // Astro gives an imported picture its own width; a smaller one is a resize, which recompression cannot do.
      const own = jpegSize(input);
      if (own && (!options.width || options.width >= own.width) && (!options.height || options.height >= own.height))
        return {data: bytes(await recompress(input, {effort, maxPixels}), options.src), format: 'jxl'};
    }
    const fidelity = {quality: asked(options.quality) ?? quality};
    if (images) return {data: bytes(await encode(new Blob([await through(images, input, options, 'image/png')], {type: 'image/png'}), {effort, maxPixels, fidelity}), options.src), format: 'jxl'};
    // Without the binding a PNG is read and resized by rapier-jxl, when the size asked keeps its shape.
    const png = source === 'png' && {width: input[16] << 24 | input[17] << 16 | input[18] << 8 | input[19], height: input[20] << 24 | input[21] << 16 | input[22] << 8 | input[23]};
    const width = png && Math.min(Math.round(options.width ?? (options.height ? options.height * png.width / png.height : png.width)), png.width);
    if (png && (!options.width || !options.height || Math.abs(Math.round(width * png.height / png.width) - Math.round(options.height)) <= 1)) {
      const blob = new Blob([input], {type: 'image/png'});
      const result = width < png.width ? (await variants(blob, {effort, maxPixels, fidelity, outputs: [{width}]}))[0] : await encode(blob, {effort, maxPixels, fidelity});
      return {data: bytes(result, options.src), format: 'jxl'};
    }
    logger.warn(`${options.src}: no Images binding in this Worker to read a ${source ?? 'picture'}; the original is served`);
  } catch (error) {
    logger.warn(`${options.src}: ${error.code ?? error.name} ${error.message}; the original is served`);
  }
  return original;
}

export default {...baseService, validateOptions, getHTMLAttributes, propertiesToHash, transform};
