// Types for svg-jxl.js.
import type {CaptureCompleteCodec} from 'jpegxl/codec';
import type {Effort} from 'jpegxl/capture-complete';

/** Any codec with capture, such as rapier-jxl/codec's capture-complete codec. */
export type CaptureEncoder = Pick<CaptureCompleteCodec, 'capture'>;
/** quality: 0..1 fraction (e.g. 0.92 = rapier-jxl quality 92, matching HTMLCanvasElement.toBlob; NOT 1..100), 0.92 by default; exact: no lossy try; cache: shared between calls, a picture is coded once. */
export type SvgJxlOptions = {
  /** A 0..1 fraction (0.92 = rapier-jxl quality 92, as HTMLCanvasElement.toBlob; not 1..100); default 0.92. 1 codes lossless. */
  quality?: number;
  /** true skips the lossy try: JPEGs restore exactly, the rest code lossless. */
  exact?: boolean;
  /** 1 (fastest) to 9 (smallest file), as rapier-jxl/capture-complete's. */
  effort?: Effort;
  /** As rapier-jxl's webgpu option. */
  webgpu?: false | 'required';
  /** Aborts the call. */
  signal?: AbortSignal;
  /** Called with 0 to 1 as pictures are coded. */
  onProgress?: (fraction: number) => void;
  /** A capture codec to code with; default one made from rapier-jxl/codec. */
  codec?: CaptureEncoder;
  /** Shared between calls: a picture is coded once. */
  cache?: Map<string, unknown>};
/** kind by its bytes; route kept, with each try's bytes; kept: why it stays; alpha: coded from the PNG's own samples. */
export type SvgJxlPicture = {kind: string; bytes?: number; jxl?: number; route: 'jpeg' | 'lossless' | 'quality' | 'kept'; tries?: {quality?: number; jpeg?: number; lossless?: number}; kept?: string; alpha?: boolean; reader?: string; url?: string};
/** The SVG's size in bytes before (bytes) and after (jxl), its pictures with how each was coded, and its font count. */
export type SvgJxlRecord = {bytes: number; jxl: number; pictures: SvgJxlPicture[]; fonts: number};
/** The same kind back, and the record. Not a sanitizer: the SVG's scripts, styles and links pass through unchanged. */
export function svgJxl<T extends string | Blob>(input: T, options?: SvgJxlOptions): Promise<{
  svg: T extends string ? string : T extends File ? File : Blob;
  record: SvgJxlRecord;
}>;
