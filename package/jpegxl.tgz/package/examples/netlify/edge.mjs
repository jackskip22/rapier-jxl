// SPDX-License-Identifier: MIT
// Netlify edge function: a JPEG or PNG the build gave a .jxl is answered with that file where the browser sends
// `Accept: image/jxl`; every other request goes on untouched. The build plug-in writes this file with the list of
// pictures it converted (WITH_JXL), so a picture with no .jxl is never sent to a missing file.
const WITH_JXL = new Set(/* paths */[]);

export default async (request, context) => {
  const {pathname} = new URL(request.url);
  if (!WITH_JXL.has(pathname)) return;
  const jxl = /\bimage\/jxl\b/.test(request.headers.get('accept') ?? '');
  let response = jxl ? await fetch(new URL(pathname.replace(/\.[^./]+$/, '.jxl'), request.url)) : null;
  if (!response?.ok) response = await context.next();
  const headers = new Headers(response.headers);
  headers.set('Vary', 'Accept');
  // Netlify's cache keeps one copy per Accept: a browser without JPEG XL is never handed one.
  headers.set('Netlify-Vary', 'header=Accept');
  return new Response(response.body, {status: response.status, headers});
};

export const config = {path: ['/*.jpg', '/*.jpeg', '/*.png', '/*.JPG', '/*.JPEG', '/*.PNG'], cache: 'manual'};
