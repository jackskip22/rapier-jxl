# rapier-jxl

`rapier-jxl` is now [`jpegxl`](https://www.npmjs.com/package/jpegxl). This package depends on `jpegxl` 8.3.5 and
gives the same modules under the old name, so existing installs keep working.

```sh
npm install jpegxl
```

Change `from 'rapier-jxl'` to `from 'jpegxl'`. Pages that import `rapier-jxl` modules from a CDN keep working. A `.wasm`
file or a classic (non-module) worker loaded by its own address does not: use the `jpegxl` address, as new pages do. MIT.
