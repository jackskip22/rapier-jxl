export * from 'jpegxl/wasm';
export {default} from 'jpegxl/wasm';
