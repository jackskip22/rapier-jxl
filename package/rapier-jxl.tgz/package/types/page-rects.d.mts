export * from 'jpegxl/page-rects';
