# rapier-jxl

JPEG XL encoder in JavaScript and WebAssembly, with WebGPU acceleration at higher effort levels.

- 45 KB Brotli exact capture encoder for screenshots and canvas.
- 106 KB Brotli page capture encoder: lossy photos, lossless text.
- 192 KB Brotli upload encoder, includes capture.
- 319 KB Brotli full still image encoder with lossless, lossy, HDR and exact alpha. Used by [rapier.html](https://rapier.website)
- Separate modules for animation, JPEG transcoding, serving and decoding. Modules are single files.
- Browsers, workers, Node, Deno, Bun, Cloudflare Workers.
- No dependencies.
- MIT.

```sh
npm install rapier-jxl
```

ESM. From CommonJS: `await import('rapier-jxl')`.

## Command line

```sh
npx rapier-jxl photo.png                  # photo.jxl beside it
npx rapier-jxl scan.jpg                   # scan.jxl, lossless; the original JPEG can be restored
npx rapier-jxl photos/ --out dist/        # every PNG, JPEG and GIF in the folder
npx rapier-jxl hero.png --max-bytes 100KB # lower quality to fit, keeping dimensions
npx rapier-jxl scan.jxl --out back/       # back/scan.jpg, the original JPEG
npx rapier-jxl photos/ --out dist/ --json  # one JSON line per file, then a summary
```

`--quality 1–100` (default 90), `--effort 1–9` (default 7), `--lossless`, `--max-bytes`, `--out`, `--jobs` (helpers).
Automatic output names never replace files.
`--json` names what each file kept: `jpeg-bytes` (the JPEG restores exactly), `pixels` (exact) or `lossy`. A rerun
leaves finished files untouched.

## Upload

```js
import {encode, fit} from 'rapier-jxl/upload';

// file: a File or Blob from an input, a drop or a fetch.
const compress = async file => new Blob([await encode(file, {fidelity: {quality: 82}})], {type: 'image/jxl'});
const small = file => fit(file, {maxBytes: 100_000}); // best quality under 100 KB
```

`variants` makes several sizes from one upload. All calls accept `onProgress` and `signal`, for progress bars and
cancelling. On Node and Deno, pass decoded pixels `{data, width, height}`; only JPEGs with `fidelity: 'exact'` and
PNGs with transparency or 16 bits can be passed as files.

## Encode

```js
import {writeFile} from 'node:fs/promises';
import {encode} from 'rapier-jxl';

const picture = {data: new Uint8Array([240, 120, 40, 255]), width: 1, height: 1};
await writeFile('picture.jxl', await encode(picture, {fidelity: {quality: 90}}));
```

Takes RGBA `{data, width, height}`, `ImageData`, a canvas (2D, WebGL or WebGPU), an `ImageBitmap`, a `VideoFrame`, a
`Blob`, a decoded image or a GPU texture `{texture, device}`, and returns a `Uint8Array`. 8 or 16-bit, `Float16Array`
or `Float32Array` samples, including HDR. For animations, use `rapier-jxl/animation`.

- `fidelity`: `{quality: 1–100}`, default 90. `'exact'` is lossless.
- `effort`: 1–9, default 7. Lower is faster; 1–3 suit previews and uploads, 8–9 photography.
- `webgpu`: efforts 7–9 use WebGPU when available. `'required'` fails without it; `false` turns it off.
- `maxPixels`: default 40 MP, up to 16,384 × 16,384. Very large images can be passed in strips with `rows(y, count)`.

## Screenshots

```js
import {capture} from 'rapier-jxl/capture';
import {capture as page} from 'rapier-jxl/capture-complete';

const screenshot = canvas => capture(canvas); // lossless
const smaller = (canvas, rects) => page(canvas, {fidelity: {webp: 0.92}, ...rects}); // lossy photos, lossless text
```

- Canvas (2D, WebGL or WebGPU), `ImageData`, an `ImageBitmap`, a `VideoFrame`, a `Blob` or 8-bit RGBA.
- `rects` is `{exactRects, photoRects}`: the areas to keep lossless, such as text, and where the photos are.
- `rapier-jxl/page-rects` finds both in a page element, for any library that draws one to a canvas.
- Pages up to 32,767 pixels tall in one file; WebP stops at 16,383. Above 40 MP, raise `maxPixels`.

| Effort | `capture-complete` |
|---|---|
| 1–3 | Fast. 3 is the default, 2 for quick saves, 1 for live previews. |
| 4 | Deeper search: smaller text and graphics, more time. |
| ~~5–6~~ | ~~Per-photo quality search.~~ |
| ~~7–9~~ | ~~Block-size search for photos, on WebGPU.~~ |

In 8.2.0, efforts 5–9 fall back to 4 for photos. Higher efforts for the capture modules are being worked on for 8.2.x.

## JPEG, decoding, metadata

```js
import {recompress, restore} from 'rapier-jxl/jpeg';
import {decode} from 'rapier-jxl/decode';
import {header} from 'rapier-jxl/metadata';

// jpeg: a Uint8Array holding a JPEG file, up to 64 MP.
const roundTrip = async jpeg => restore(await recompress(jpeg));
const pixels = async file => decode(file); // {width, height, data}, RGBA
const size = file => header(file); // synchronous, from a file or its first bytes
```

`rapier-jxl/svg-jxl` converts the images inside any SVG to JPEG XL where that makes them smaller, keeping text and shapes as they are.
`{exact: true}` keeps the images lossless.

## Serving

For recompressed JPEGs, `serve` sends JPEG XL to browsers that support it and the original JPEG to the rest, with
`Vary: Accept`, ETag, `304` and `HEAD`.

```js
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {serve} from 'rapier-jxl/serve';

// photo.jxl, made once: npx rapier-jxl photo.jpg
const stored = await readFile('photo.jxl');
createServer((req, res) => serve(stored, req, res)).listen(3000);
```

Cloudflare Workers, Deno and Bun: `return serve(stored, request)`. `cacheControl` sets `Cache-Control` (default
`private, no-cache`).

## Workers and queues

```js
import {createCodec} from 'rapier-jxl/codec';

const queue = createCodec({module: 'rapier-jxl/upload', helpers: {count: 3, memoryBytes: 1 << 30}});
const photo = (width, height) => ({data: new Uint8Array(width * height * 4).fill(200), width, height});
try {
  const files = await Promise.all([photo(1200, 900), photo(300, 225)].map(picture => queue.encode(picture)));
} finally {
  await queue.close();
}
```

- In browsers, the module runs in a worker (upload: 219 KB Brotli). Node, Deno and Bun run it in the calling thread.
- `helpers` adds up to 16 worker threads; `helpers: true` sizes them by the device.
- Errors carry a `code`, such as `JXL_INPUT`, `JXL_OPTIONS`, `JXL_WASM` or `JXL_WEBGPU`.

## Browsers

```html
<script type="module">
  import {encode} from 'https://cdn.jsdelivr.net/npm/rapier-jxl@8/dist/index.mjs';
  const bytes = await encode(document.querySelector('canvas'));
</script>
```

- Content Security Policy: `'wasm-unsafe-eval'`; `worker-src blob:` for `rapier-jxl/codec` from a CDN.
- Every module needs WebAssembly with SIMD (`JXL_WASM` without it), except `restore` and `metadata`.
- Without native JPEG XL: `import 'rapier-jxl/polyfill'`.
- Vite: `worker: {format: 'es'}`. webpack 5, Parcel, Angular and Next.js work as is. Next.js edge routes: import
  modules directly, not `rapier-jxl/codec`.
- Rollup: `@web/rollup-plugin-import-meta-assets` with `assetFileNames: 'assets/[name][extname]'`.
- esbuild: copy `rapier-jxl/dist/*.worker.mjs` and `*.helper.mjs` beside the bundle.

Node 20.16+ or 22.3+, Deno, Bun, Cloudflare Workers.

## License

MIT. Third-party notices: `THIRD_PARTY_NOTICES`.

## Contributing

Anybody is welcome to contribute to rapier-jxl, which is intended to be as universal as possible.

For feedback, requests or questions, feel free to join the discussion. The goal is to make rapier-jxl as easy, fast, small, powerful and reliable as possible for every use case, while keeping the architecture simple and general.

Examples and plugins can be added for very common use cases.
